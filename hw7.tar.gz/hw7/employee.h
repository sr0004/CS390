#ifndef EMPLOYEE_H
#define EMPLOYEE_H //Include guards



struct employee{

char firstname[15]; //Char array containing first name for comparisons
char lastname[15];  //Char array containing last name for comparisons
};

void EmployeeSearch(const char*);	//prototype for EmployeeSearch


#endif
